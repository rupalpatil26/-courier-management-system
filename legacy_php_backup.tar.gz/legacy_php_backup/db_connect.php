<?php 

try {
    $conn = new PDO('sqlite:' . __DIR__ . '/database/cms_db.sqlite');
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->sqliteCreateFunction('concat', function(...$args) {
        return implode('', $args);
    });
    $conn->sqliteCreateFunction('unix_timestamp', function($date = null) {
        if ($date === null) return time();
        return strtotime($date);
    });
    // Initialize system settings in session if session active and not already set
    if (session_status() === PHP_SESSION_ACTIVE && empty($_SESSION['system'])) {
        $stmt = $conn->query("SELECT * FROM system_settings LIMIT 1");
        $system = $stmt ? $stmt->fetch(PDO::FETCH_ASSOC) : [];
        if ($system) {
            foreach ($system as $k => $v) {
                $_SESSION['system'][$k] = $v;
            }
        }
    }
} catch (Exception $e) {
    die("Could not connect to sqlite: " . $e->getMessage());
}
