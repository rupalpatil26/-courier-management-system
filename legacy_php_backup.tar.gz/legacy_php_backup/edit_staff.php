<?php
include 'db_connect.php';
$qry = $conn->query("SELECT * FROM users where id = ".$_GET['id'])->fetch(PDO::FETCH_ASSOC);
foreach($qry as $k => $v){
	$$k = $v;
}
include 'new_staff.php';
?>